<div class="header">
  <div class="Logoheader"></div>

  <div class="nav">
  <div class="navMain"><a href="main.html">ГЛАВНАЯ</a></div>

  <div class="navMarvel"><a href="marvel.html">MARVEL</a></div>

  <div class="navDc"><a href="dc.html">DC</a></div>

  <div class="navManga"><a href="manga.html">MANGA</a></div>

  <div class="navBest"><a href="best.html">BEST</a></div>
  </div>
  
  <div class="user-menu">
    <div class="user-menuSign">
    <?php echo "SIGN IN";?> </div>

    <div class="user-menuSeporator">
    <?php echo "|";?></div>
    
    <div class="user-menuLogin">
    <?php echo "LOGIN";?></div>
  </div>

  <div class="user-search">
  <div class="user-searchS">
  <form><input type="text" placeholder="Искать здесь...">
  <button type="submit"></button></form></div>
  </div>

  <div class="Profilheader"></div>
  <div class="EraCoinheader"></div>
</div>